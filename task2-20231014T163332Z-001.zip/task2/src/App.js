import './App.css';
import Caluclator from './Caluclator';

function App() {
  return (
    <div className="App">
      <Caluclator/>
    </div>
  );
}

export default App;
