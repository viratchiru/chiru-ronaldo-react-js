import './App.css';
import './WordCounter'
import WordCounter from './WordCounter';
function App() {
  return (
    <div className="App">
      <WordCounter/>
    </div>
  );
}

export default App;
