
import './App.css';
import AgeCalc from './AgeCalc';

function App() {

  
  return (
    <div className="App">
      <AgeCalc/>
    </div>
  );
}

export default App;
