import './App.css';
import UserTable from './UserTable';

function App() {
  return (
    <div className="App">
    <UserTable/>
    </div>
  );
}

export default App;
